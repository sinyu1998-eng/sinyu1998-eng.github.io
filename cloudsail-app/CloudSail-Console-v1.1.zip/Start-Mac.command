#!/bin/bash
cd "$(dirname "$0")"
open "CloudSail-Console.html"
